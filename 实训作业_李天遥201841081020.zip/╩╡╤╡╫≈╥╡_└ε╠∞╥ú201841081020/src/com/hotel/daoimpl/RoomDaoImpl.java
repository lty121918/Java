/**
 * 
 */
package com.hotel.daoimpl;

import com.hotel.util.JDBCUtil;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.hotel.dao.RoomDao;
import com.hotel.entity.Customer;
import com.hotel.entity.Room;

/**
 * @ClassName: RoomDaoImpl
 * @Description:�������ʵ��
 * @author: ����ң
 * @date 2020��6��12�� ����6:23:30
 * @version V1.0
 */

public class RoomDaoImpl implements RoomDao {
	private JDBCUtil jdbc = new JDBCUtil();

	@Override
	public Room open(String number) {

		ResultSet rs = jdbc.query("select * from room where room_id=? ", number);// ��ѯ�����
		// TODO Auto-generated method stub
		Room room = null;

		try {
			if (rs != null && rs.next()) {
				room = new Room();
				room.setRoom_id(rs.getInt("room_id"));
//				user.setUser_birthday(rs.getString("user_birthday"));
//				user.setUser_email(rs.getString("user_email"));
//				user.setUser_lname(rs.getString("user_lname"));
//				user.setUser_lpwd(rs.getString("user_lpwd"));
//				user.setUser_rname(rs.getString("user_rname"));
//				user.setUser_role(rs.getInt("user_role"));
//				user.setUser_salary(rs.getDouble("user_salary"));
//				user.setUser_sex(rs.getString("user_sex"));
//				user.setUser_status(rs.getInt("user_status"));
//				user.setUser_tel(rs.getString("user_tel"));
//				user.setUser_time(rs.getString("user_time"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			jdbc.closeAll();
		}

		return room;

	}

	@Override
	public Room date(String startdate, String enddate) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
