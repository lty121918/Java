/**
 * 
 */
package com.hotel.entity;

/**  
 * @ClassName: Customer 
 * @Description:�Ƶ�˿�ʵ����
 * @author: ����ң
 * @date 2020��6��12�� ����9:32:42 
 * @version V1.0
 */
public class Customer {
private  String customer_room;
private  String customer_name;
private  String customer_sex;
private  String customer_IDnumber;
private  String customer_tel;
private  String customer_startDate;
private  String customer_endDate;

public String getCustomer_room() {
	return customer_room;
}
public void setCustomer_room(String customer_room) {
	this.customer_room = customer_room;
}
public String getCustomer_name() {
	return customer_name;
}
public void setCustomer_name(String customer_name) {
	this.customer_name = customer_name;
}
public String getCustomer_sex() {
	return customer_sex;
}
public void setCustomer_sex(String customer_sex) {
	this.customer_sex = customer_sex;
}
public String getCustomer_IDnumber() {
	return customer_IDnumber;
}
public void setCustomer_IDnumber(String customer_IDnumber) {
	this.customer_IDnumber = customer_IDnumber;
}
public String getCustomer_tel() {
	return customer_tel;
}
public void setCustomer_tel(String customer_tel) {
	this.customer_tel = customer_tel;
}
public String getCustomer_startDate() {
	return customer_startDate;
}
public void setCustomer_startDate(String customer_startDate) {
	this.customer_startDate = customer_startDate;
}
public String getCustomer_endDate() {
	return customer_endDate;
}
public void setCustomer_endDate(String customer_endDate) {
	this.customer_endDate = customer_endDate;
}




}
