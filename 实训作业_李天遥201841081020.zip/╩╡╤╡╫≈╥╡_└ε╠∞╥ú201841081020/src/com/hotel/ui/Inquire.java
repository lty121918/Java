/**
 * 
 */
package com.hotel.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.hotel.dao.CustomerDao;
import com.hotel.daoimpl.CustomerDaoImpl;
import com.hotel.entity.Customer;



import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.util.List;
import java.awt.event.ActionEvent;

/**  
 * @ClassName: Inquire 
 * @Description:
 * @author: ����ң
 * @date 2020��6��13�� ����5:25:14 
 * @version V1.0
 */
public class Inquire extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Inquire frame = new Inquire();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Inquire() {
		setTitle("\u623F\u95F4\u67E5\u8BE2");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 679, 369);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		String number = null;
		int a = 0,b = 0;
		CustomerDao dao=new CustomerDaoImpl(); 
//		for(a=1;a<4;a++){
//			for(b=1;b<6;b++) {
//				 number = String.valueOf(a*100+b);
//				number.setBackground(Color.BLUE);
//					System.out.println(number);
//					Customer cust=dao.queryId(number);
//	                System.out.println(cust);
//			}
//		}
		
		
		
		
		JButton btnNewButton = new JButton("\u67E5\u8BE2");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				///////���༭
				CustomerDao dao=new CustomerDaoImpl(); 
				String ss="301";
		    	
				//JButton temp = new JButton();
				//temp.setText("��" + (i * 100 + j));
				// temp.setIcon(icon);
				if(dao.queryId(ss)==null) {
				setBackground(Color.BLUE);
				List<Customer> Master = null;
				
					// //��ȡ������������
					Master = dao.queryAll();
					JOptionPane
					.showMessageDialog(
							null,
							
									 "�ŷ��� "
									+ "\n"
									+ "����Ϊ"
									//+ Master
									+ "\n"
									+ "�Ӵ�ߴ�ġ����пյ�"
									+ "\n"
									+ "����������ԡ�豸��25Ӣ�������ɫ���µ��ӡ� �绰�� �����ĳ����� "
									+ "\n"
									+ "��ɻ��� ��ʱ�ӵ��������Լ����ڵİ�ȫ�ͼ���װ��");

				}
				}
				
		});
			
	
		
		
		
		btnNewButton.setBounds(406, 57, 113, 27);
		contentPane.add(btnNewButton);
		
		textField = new JTextField();
		textField.setBounds(138, 57, 237, 26);
		contentPane.add(textField);
		textField.setColumns(10);

		JButton �󴲷�102 = new JButton("101");
		�󴲷�102.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JButton temp = new JButton();
				�󴲷�102.setBackground(Color.BLUE);
				JOptionPane.showMessageDialog(null,
						
								 "101�ŷ��� "
								+ "\n"
								+ "����Ϊ"
								
								+ "\n"
								+ "�Ӵ�ߴ�ġ����пյ�"
								+ "\n"
								+ "����������ԡ�豸��25Ӣ�������ɫ���µ��ӡ� �绰�� �����ĳ����� "
								+ "\n"
								+ "��ɻ��� ��ʱ�ӵ��������Լ����ڵİ�ȫ�ͼ���װ��");

				
				
			}
		});
		�󴲷�102.setBounds(36, 122, 118, 46);
		contentPane.add(�󴲷�102);
		
		JButton �󴲷�101 = new JButton("102");
		�󴲷�101.setBounds(156, 122, 118, 46);
		contentPane.add(�󴲷�101);
		
		JButton btnNewButton_1_2 = new JButton("103");
		btnNewButton_1_2.setBounds(275, 122, 118, 46);
		contentPane.add(btnNewButton_1_2);
		
		JButton btnNewButton_1_3 = new JButton("104");
		btnNewButton_1_3.setBounds(395, 122, 118, 46);
		contentPane.add(btnNewButton_1_3);
		
		JButton btnNewButton_1_4 = new JButton("201");
		btnNewButton_1_4.setBounds(36, 169, 118, 46);
		contentPane.add(btnNewButton_1_4);
		
		JButton btnNewButton_1_5 = new JButton("202");
		btnNewButton_1_5.setBounds(156, 169, 118, 46);
		contentPane.add(btnNewButton_1_5);
		
		JButton btnNewButton_1_6 = new JButton("203");
		btnNewButton_1_6.setBounds(275, 169, 118, 46);
		contentPane.add(btnNewButton_1_6);
		
		JButton btnNewButton_1_6_1 = new JButton("204");
		btnNewButton_1_6_1.setBounds(395, 169, 118, 46);
		contentPane.add(btnNewButton_1_6_1);
		
		JButton btnNewButton_1_6_2 = new JButton("301");
		btnNewButton_1_6_2.setBounds(36, 217, 118, 46);
		contentPane.add(btnNewButton_1_6_2);
		
		JButton btnNewButton_1_6_3 = new JButton("302");
		btnNewButton_1_6_3.setBounds(156, 217, 118, 46);
		contentPane.add(btnNewButton_1_6_3);
		
		JButton btnNewButton_1_6_4 = new JButton("303");
		btnNewButton_1_6_4.setBounds(275, 217, 118, 46);
		contentPane.add(btnNewButton_1_6_4);
		
		JButton btnNewButton_1_6_5 = new JButton("304");
		btnNewButton_1_6_5.setBounds(395, 217, 118, 46);
		contentPane.add(btnNewButton_1_6_5);
		
		JButton btnNewButton_1_6_9_1 = new JButton("105");
		btnNewButton_1_6_9_1.setBounds(514, 122, 118, 46);
		contentPane.add(btnNewButton_1_6_9_1);
		
		JButton btnNewButton_1_6_9_2 = new JButton("205");
		btnNewButton_1_6_9_2.setBounds(514, 169, 118, 46);
		contentPane.add(btnNewButton_1_6_9_2);
		
		JButton btnNewButton_1_6_9_3 = new JButton("305");
		btnNewButton_1_6_9_3.setBounds(514, 217, 118, 46);
		contentPane.add(btnNewButton_1_6_9_3);
		for(a=1;a<4;a++){
			for(b=1;b<6;b++) {
				 number = String.valueOf("�󴲷�"+a*100+b);
				// number.setBackground(Color.BLUE);
				 int i=102;
				String s= String.valueOf(i);
				 
				
				
					System.out.println(number);
					Customer cust=dao.queryId(number);
	                System.out.println(cust);
	                if(cust==null) {
	                	 btnNewButton_1_6_3.setBackground(Color.BLUE);
	                	 btnNewButton_1_6_9_2.setBackground(Color.BLUE);
	                }
			}
		}
	}
	}		
		
