package com.hotel.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.hotel.dao.CustomerDao;
import com.hotel.daoimpl.CustomerDaoImpl;
import com.hotel.entity.Customer;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class InquireCustomer extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTable table;
	private JScrollPane scrollPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {

			public void run() {
				try {
					InquireCustomer frame = new InquireCustomer();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public InquireCustomer() {
		setTitle("\u987E\u5BA2\u4FE1\u606F\u67E5\u8BE2");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 604, 470);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel label = new JLabel("\u5173\u952E\u5B57\uFF1A");
		label.setBounds(52, 36, 65, 18);
		contentPane.add(label);

		textField = new JTextField();
		textField.setBounds(111, 33, 332, 24);
		contentPane.add(textField);
		textField.setColumns(10);

		JButton button = new JButton("\u641C\u7D22");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// ��ȡ������еĹؼ���
				String key = textField.getText();
				CustomerDao dao2 = new CustomerDaoImpl();
				List<Customer> list2 = dao2.queryByKey(key);

				// ����������
				String[] columns = { "�˿�����", "�����", "�Ա�", "�绰", "��סʱ��", "���ʱ��" };

				// �����ά����
				String[][] data = new String[list2.size()][columns.length];
				for (int i = 0; i < list2.size(); i++) {
					for (int j = 0; j < columns.length; j++) {
						if (j == 0) {
							data[i][j] = list2.get(i).getCustomer_name();
						}
						if (j == 1) {
							data[i][j] = list2.get(i).getCustomer_room();
						}
						if (j == 2) {
							data[i][j] = list2.get(i).getCustomer_sex();
						}
						if (j == 3) {
							data[i][j] = list2.get(i).getCustomer_tel();
						}
						if (j == 4) {
							data[i][j] = list2.get(i).getCustomer_startDate();
						}
						if (j == 5) {
							data[i][j] = list2.get(i).getCustomer_endDate();
						}
					

					}
				}

				// 1 ��ȡtable����������
				DefaultTableModel dtm = (DefaultTableModel) table.getModel();
				// 2 ����������װ�䵽������
				dtm.setDataVector(data, columns);

			}
		});
		button.setBounds(453, 32, 84, 27);
		contentPane.add(button);

		scrollPane = new JScrollPane();
		scrollPane.setBounds(52, 94, 485, 279);
		contentPane.add(scrollPane);

		table = new JTable();
		scrollPane.setViewportView(table);
		table.setEnabled(false);

		// ��ѯ���е��û���������Щ�û��Ĳ�����Ϣ
		CustomerDao dao = new CustomerDaoImpl();
		List<Customer> list = dao.queryAllForPart();

		// ����������
		String[] columns = { "�˿�����", "�����", "�Ա�", "�绰", "��סʱ��", "���ʱ��" };

		// �����ά����
		String[][] data = new String[list.size()][columns.length];
		for (int i = 0; i < list.size(); i++) {
			for (int j = 0; j < columns.length; j++) {
				if (j == 0) {
					data[i][j] = list.get(i).getCustomer_name();
				}
				if (j == 1) {
					data[i][j] = list.get(i).getCustomer_room();
				}
				if (j == 2) {
					data[i][j] = list.get(i).getCustomer_sex();
				}
				if (j == 3) {
					data[i][j] = list.get(i).getCustomer_tel();
				}
				if (j == 4) {
					data[i][j] = list.get(i).getCustomer_startDate();
				}
				if (j == 5) {
					data[i][j] = list.get(i).getCustomer_endDate();
				}
				
			}
		}

		// 1 ��ȡtable����������
		DefaultTableModel dtm = (DefaultTableModel) table.getModel();
		dtm.setDataVector(data, columns);

	}
}
