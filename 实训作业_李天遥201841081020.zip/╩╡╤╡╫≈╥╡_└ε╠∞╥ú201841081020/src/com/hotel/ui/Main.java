/**
 * 
 */
package com.hotel.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

//import com.etc.emp.ui.Login;
//import com.etc.emp.ui.Manager;
import com.hotel.entity.Room;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;

/**
 * @ClassName: Main
 * @Description:�Ƶ����ϵͳ������
 * @author: ����ң
 * @date 2020��6��12�� ����9:58:33
 * @version V1.0
 */
public class Main extends JFrame {

	private JPanel contentPane;

	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() {
		
		setFont(new Font("����", Font.PLAIN, 12));
		setTitle("\u9152\u5E97\u7BA1\u7406\u7CFB\u7EDF\u4E3B\u754C\u9762");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 640, 488);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton btnNewButton = new JButton("\u5F00\u623F\u767B\u8BB0");
		btnNewButton.setFont(new Font("����", Font.PLAIN, 18));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// JOptionPane.showMessageDialog(null, "��һ�ڿ��֣�������");
				//Room room = new Room();
				OpenRoom ro = new OpenRoom();
				ro.setVisible(true);
				ro.setLocationRelativeTo(null);
				// ����ǰ�ĵ�¼���ڹر�
				Main.this.dispose();
			}
		});
		btnNewButton.setBounds(130, 175, 132, 50);
		//���ð�ť����͸��
				btnNewButton.setContentAreaFilled(false);  
		contentPane.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("\u9000\u623F");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Delete del=new Delete();
				del.setVisible(true);
				del.setLocationRelativeTo(null);
				// ����ǰ�ĵ�¼���ڹر�
				Main.this.dispose();
				
			}
		});
		btnNewButton_1.setFont(new Font("����", Font.PLAIN, 18));
		btnNewButton_1.setBounds(349, 175, 132, 50);
		  
		// ���ð�ť�ޱ߿�  btnNewButton_1.setBorderPainted(false);  
		  
		//���ð�ť����͸��
		btnNewButton_1.setContentAreaFilled(false);  
		contentPane.add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("\u623F\u95F4\u67E5\u8BE2");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				Inquire inq = new Inquire();
				inq.setVisible(true);
				inq.setLocationRelativeTo(null);
				// ����ǰ�ĵ�¼���ڹر�
				Main.this.dispose();
				
			}
		});
		btnNewButton_2.setFont(new Font("����", Font.PLAIN, 18));
		btnNewButton_2.setBounds(130, 261, 132, 50);
		//���ð�ť����͸��
				btnNewButton_2.setContentAreaFilled(false);  
		contentPane.add(btnNewButton_2);

		JButton btnNewButton_3 = new JButton("\u66F4\u6362\u623F\u95F4");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Replace rep=new Replace();
				rep.setVisible(true);
				rep.setLocationRelativeTo(null);
				// ����ǰ�ĵ�¼���ڹر�
				Main.this.dispose();
				
				
				
			}
		});
		btnNewButton_3.setFont(new Font("����", Font.PLAIN, 18));
		btnNewButton_3.setBounds(349, 267, 132, 44);
		//���ð�ť����͸��
		btnNewButton_3.setContentAreaFilled(false);  
		contentPane.add(btnNewButton_3);

		JLabel lblNewLabel = new JLabel("\u9152\u5E97\u7BA1\u7406\u7CFB\u7EDF");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("����", Font.BOLD, 26));
		lblNewLabel.setBounds(198, 63, 225, 63);
		contentPane.add(lblNewLabel);
		//����ͼƬ
		JLabel image = new JLabel("");
		image.setBounds(0,0,800,800);
		image.setIcon(new ImageIcon("image/test.jpeg"));
		contentPane.add(image);
		
		
		

		
	}
}
